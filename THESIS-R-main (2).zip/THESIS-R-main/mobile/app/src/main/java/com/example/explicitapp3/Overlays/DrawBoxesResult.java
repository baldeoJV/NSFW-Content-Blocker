package com.example.explicitapp3.Overlays;

import android.graphics.Bitmap;

public class DrawBoxesResult {
    Bitmap mutableBitmap;

}
