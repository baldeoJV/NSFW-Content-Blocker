# THESIS-

Official repository for CS Thesis

-   Android studio [project documentation](https://github.com/baldeoJV/THESIS-/blob/main/mobile/README.md)
